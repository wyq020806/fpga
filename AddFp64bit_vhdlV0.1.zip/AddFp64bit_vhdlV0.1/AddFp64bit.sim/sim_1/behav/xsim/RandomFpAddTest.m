 
clc
for i = 1:1024
    X(i) = (rand()-0.5)*100;
end

for i = 1:1024
    Y(i) = (rand()-0.5)*100;
end

for i = 1:1024
    R(i) = X(i)+Y(i);
end

% InputX.txt
XHex = num2hex(X);
% InputY.txt
YHex = num2hex(Y);
% OutputR.txt
RHex = num2hex(R);
% end




